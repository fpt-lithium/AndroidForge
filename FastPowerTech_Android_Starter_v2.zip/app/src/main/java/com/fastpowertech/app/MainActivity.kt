package com.fastpowertech.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

class MainActivity : Activity() {
    private val APK_DOWNLOAD_URL = "https://example.com/fastpowertech.apk"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 48, 36, 48)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
        root.addView(TextView(this).apply {
            text = "Fast Power Tech"
            textSize = 28f
            gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Battery QR Scanner & App Download"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 30)
        })
        root.addView(Button(this).apply {
            text = "QR স্ক্যান করুন"
            setOnClickListener { scanQr() }
        })
        root.addView(Button(this).apply {
            text = "অ্যাপ ডাউনলোড"
            setOnClickListener { openDownload() }
        })
        root.addView(Button(this).apply {
            text = "Install Permission নির্দেশনা"
            setOnClickListener { showPermissionHelp() }
        })
        setContentView(root)
    }

    private fun scanQr() {
        val scanner = GmsBarcodeScanning.getClient(this)
        scanner.startScan()
            .addOnSuccessListener { barcode ->
                val value = barcode.rawValue.orEmpty()
                if (value.startsWith("https://") || value.startsWith("http://")) {
                    AlertDialog.Builder(this).setTitle("QR লিংক পাওয়া গেছে")
                        .setMessage(value)
                        .setPositiveButton("লিংক খুলুন") { _, _ ->
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(value)))
                        }.setNegativeButton("বন্ধ করুন", null).show()
                } else {
                    AlertDialog.Builder(this).setTitle("QR তথ্য")
                        .setMessage(value.ifBlank { "QR কোডে কোনো তথ্য পাওয়া যায়নি।" })
                        .setPositiveButton("ঠিক আছে", null).show()
                }
            }
            .addOnFailureListener { showMessage("QR স্ক্যান করা যায়নি। আবার চেষ্টা করুন।") }
    }

    private fun openDownload() {
        if (APK_DOWNLOAD_URL.contains("example.com")) {
            showMessage("প্রথমে APK প্রকাশ করে MainActivity.kt-তে আসল ডাউনলোড লিংক বসাতে হবে।")
            return
        }
        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(APK_DOWNLOAD_URL)))
    }

    private fun showPermissionHelp() {
        AlertDialog.Builder(this)
            .setTitle("অ্যাপ ইনস্টল করার অনুমতি")
            .setMessage("APK ডাউনলোড করার পর Android সেটিংসে ব্রাউজার/ফাইল অ্যাপের জন্য 'Allow from this source' চালু করতে হতে পারে। এরপর Install চাপুন। এই অনুমতি ব্যবহারকারী নিজে চালু করবেন।")
            .setPositiveButton("সেটিংস খুলুন") { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                        Uri.parse("package:$packageName")))
                } catch (_: Exception) {
                    showMessage("Settings > Apps > Special app access > Install unknown apps থেকে অনুমতি দিন।")
                }
            }
            .setNegativeButton("পরে", null).show()
    }

    private fun showMessage(text: String) {
        AlertDialog.Builder(this).setMessage(text).setPositiveButton("ঠিক আছে", null).show()
    }
}
