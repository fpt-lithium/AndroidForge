# Fast Power Tech Android Starter v2

এটি source project scaffold, তৈরি APK নয়।

## কী আছে
- QR scanner (Google Code Scanner API)
- APK ডাউনলোডের বাটন
- Android install permission নির্দেশনা
- Fast Power Tech হোম স্ক্রিন

## গুরুত্বপূর্ণ
1. `app/src/main/java/com/fastpowertech/app/MainActivity.kt` ফাইলে `APK_DOWNLOAD_URL`-এ আপনার প্রকাশিত APK-এর আসল HTTPS লিংক বসাতে হবে।
2. `gradlew` ও `gradlew.bat` wrapper scripts এই ZIP-এ রাখা হয়নি। Android Studio বা সমর্থিত online build service-এর নিজের Gradle setup লাগতে পারে।
3. APK তৈরি করতে Android SDK/Gradle environment দরকার।
4. Li Power/GPS/BMS live data এখনো সংযুক্ত নয়; vendor API/server access বা নিজস্ব backend লাগবে।
5. QR scanning-এর Google dependency প্রথম build-এ internet থেকে নামবে।
